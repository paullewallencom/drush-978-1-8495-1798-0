<?php
/**
 * @file
 * Site alias for local site alias called "Drupal"
 */
$aliases['drupal'] = array(
  // Set here the path to the root of your Drupal installation.
  'root' => '/home/juampy/projects/drupal/',
  // Here goes the URL of your site.
  'uri'  => 'drupal.localhost',
);
